#include <stdio.h>
#include <stdlib.h>

#include "hash.h"


void init_hashtable(int size, Rapper* hash_table[]) {

	for (int i = 0; i < size; i++) {
		hash_table[i] = NULL;
	}

}

int hash(int size, Rapper* hash_table[], Rapper* r) {

	return r->num % size;
	
}

void hash_add(int size, Rapper* hash_table[], Rapper* value) {

	if (value == NULL) return;

	int key = hash(size, hash_table, value);

	while (1) {


		if (hash_table[key] == NULL) {
			hash_table[key] = value;
			break;
		}
		
		else key = (key + 1) % size;
	}
	
	
}

void hash_delete(int size, Rapper* hash_table[], Rapper* value) {

	if (value == NULL) return;

	int key = hash(size, hash_table, value);

	while (1) {

		if (hash_table[key] == value) {
			hash_table[key] = NULL;
			break;
		}

		key = (key + 1) % size;
	}
}

int hash_search(int size, Rapper* hash_table[], Rapper* value) {

	if (value == NULL) return;

	int key = hash(size, hash_table, value);
	int i = key;

	while (1) {

		if (hash_table[i] == value) {
			return i;
		}
		
		i = (i + 1) % size;
	
		if (i == key) return -1;
	}


}