#include <stdio.h>
#include "stack.h"
#pragma warning(disable:4996)


void init_stack(Stack* s) {

	s->size = 0;
	s->top = NULL;

}

int is_stack_full(Stack* s) {

	if (s->size == MAX_STACK_SIZE) return 1;
	else return 0;

}

int is_stack_empty(Stack* s) {

	return (s->top == NULL);

}

void push(Stack* s, struct tree_node* value) {

	SN* node = (SN*)malloc(sizeof(SN));
	node->value = value;


	if (is_stack_full(s)) printf("STACK FULL ERROR\n");

	else if (is_stack_empty(s)) {
		node->link = NULL;
		s->top = node;
		s->size++;
	}

	else {
		node->link = s->top;
		s->top = node;
		s->size++;
	}

}

struct tree_node* pop(Stack* s) {

	TN* ret = NULL;

	if (is_stack_empty(s)) {
		
		//printf("STACK EMPTY ERROR\n");
		return NULL;

	}

	else {
		SN* del = s->top;
		s->top = del->link;
		ret = del->value;
		free(del);
		s->size--;

		return ret;
	}

}

