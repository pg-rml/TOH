#pragma once
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

#include "stack.h"


typedef struct tree_node {

	char value;
	struct tree_node* left;
	struct tree_node* right;

}TN;

typedef struct tree {

	TN* root;

}Tree;

void init_tree(Tree* t);

void print_tree(Tree* t);

void link_left(TN* pre, TN* node);

void link_right(TN* pre, TN* node);

int tree_calculate(Tree* t);