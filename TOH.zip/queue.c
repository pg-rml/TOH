#include <stdio.h>
#include <string.h>
#include "queue.h"
#pragma warning(disable:4996)

void init_queue(Queue* q) {

	q->size = 0;
	q->front = NULL;
	q->rear = NULL;

}

int is_queue_full(Queue* q) {

	if (q->size == MAX_QUEUE_SIZE) return 1;
	else return 0;

}

int is_queue_empty(Queue* q) {

	return (q->front == NULL);

}

void enqueue(Queue* q, char* value) {

	QN* node = (QN*)malloc(sizeof(QN));
	strcpy(node->value, value);

	if (is_queue_full(q)) printf("QUEUE FULL ERROR\n");

	else if (is_queue_empty(q)) {
		q->front = node;
		q->rear = node;
		node->link = NULL;
		q->size++;
	}

	else {
		q->rear->link = node;
		q->rear = node;
		node->link = NULL;
		q->size++;
	}
}

char* dequeue(Queue* q) {

	char temp[100];

	if (is_queue_empty(q)) printf("QUEUE EMPTY ERROR\n");

	else {
		QN* del = q->front;
		q->front = del->link;
		strcpy(temp, del->value);
		free(del);
		q->size--;
	}

	return temp;
}

void print_queue(Queue* q) {
	
	for (QN* p = q->front; p != NULL; p = p->link) {

		printf("%s\n", p->value);

	}

	printf("\n");
}