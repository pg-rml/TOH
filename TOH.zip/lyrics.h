#pragma once
#include <stdio.h>

char LYRICS[3][10][100];

void init_lyrics();