#include "tree.h"
#include "stack.h"

void init_tree(Tree* t) {

	TN* tn1 = (TN*)malloc(sizeof(TN));
	TN* tn2 = (TN*)malloc(sizeof(TN));

	tn1->value = '+';
	tn1->right = NULL;

	tn2->value = '*';
	tn2->left = NULL;
	tn2->right = NULL;

	tn1->left = tn2;
	t->root = tn1;

}


void print_tree(Tree* t) {

	Stack s; 
	init_stack(&s);
	TN* root = t->root;
	

	while (1) {
		for (; root != NULL; root = root->left) {
			push(&s, root);
		}
		root = pop(&s);
		if (root == NULL) break;;
		printf("%c ", root->value);
		root = root->right;
	}

}

void link_left(TN* pre, TN* node) {
	pre->left = node;
}

void link_right(TN* pre, TN* node) {
	pre->right = node;
}

int tree_calculate(Tree* t) {

	int node1 = (int)t->root->left->left->value - 48;
	int node2 = (int)t->root->left->right->value - 48;
	int node3 = (int)t->root->right->value - 48;

	return node1 * node2 + node3;

}