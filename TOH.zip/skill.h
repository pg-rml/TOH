#pragma once

int make_some_noise(Rapper* r);

int taunt();

int off_beat(Rapper* r);