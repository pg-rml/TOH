#pragma once
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>

#include "rapper.h"



Rapper* quarter_enemy[5];
Rapper* semi_enemy[3];

void init_hashtable(int size, Rapper* hash_table[]);

int hash(int size, Rapper* hash_table[], Rapper* r);

void hash_add(int size, Rapper* hash_table[], Rapper* value);

void hash_delete(int size, Rapper* hash_table[], Rapper* value);

int hash_search(int size, Rapper* hash_table[], Rapper* value);