#pragma warning(disable:4996)
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "queue.h"
#include "judge.h"
#include "rapper.h"


int string_length(char* str)
{
	int i = 0;
	int size = 0;

	for (;;i++) {
		
		if (str[i] & 0x80) {
			size++;
			i++;
		}
		
		else if (str[i] == 0)  break;
		
		else size++;
	
	}

	return size;

}


void init_judge(Judge* j) {

	j->audience_player = 10;
	j->audience_enemy = 10;

	for (int i = 0; i < 4; i++) {
		j->score_player[i] = 0;
		j->score_enemy[i] = 0;
	}


	for (int i = 0; i < 4; i++) {
		strcpy(j->lyrics_player[i], "\0");
		strcpy(j->lyrics_enemy[i], "\0");
	}

}

int judge_length(char lyrics[][100]) {

	int sum = 0;
	int avg = 0;
	int size_array[4];
	
	int sum_devi = 0; // ������ ��

	int temp = 0;

	for (int i = 0; i < 4; i++) {

		size_array[i] = string_length(lyrics[i]);
		sum += size_array[i];

	}

	avg = sum / 4;


	for (int i = 0; i < 4; i++) {

		temp = avg - size_array[i];
		if (temp < 0) temp = temp * (-1);

		sum_devi += temp;

	}

	sum_devi /= 4;
	return sum_devi;

}

int judge_listen(Rapper* r) {

	return r->delivery + r->voice;

}

int judge_rhyme(char lyrics[][100]) {

	int score = 0;

	for (int i = 0; i < 3; i++) {
		if (lyrics[0][0] == lyrics[i+1][0]) {
			score += 1;
		}
	}

	for (int i = 1; i < 3; i++) {
		if (lyrics[1][0] == lyrics[i+1][0]) {
			score += 1;
		}
	}

	if (lyrics[2][0] == lyrics[3][0]) score += 1;
 	
	return score; 

}


void judge_sum(Judge* j, int who, Rapper* p, Rapper* e) {

	char** temp = NULL;
	int* score = NULL;

	Rapper* t = NULL;

	if (who == 0) {
		temp = j->lyrics_player;
		score = j->score_player;
		t = p;
	}

	else {
		temp = j->lyrics_enemy;
		score = j->score_enemy;
		t = e;
	}	
	
	score[0] += 10 - judge_length(temp);
	score[1] += judge_listen(t);
	score[2] += 5 + judge_rhyme(temp);

	for (int i = 0; i < 3; i++) {
		//printf("%d\n", score[i]);
		score[3] += score[i];
	}
}

