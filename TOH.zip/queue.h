#pragma once
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_QUEUE_SIZE 4

typedef struct queue_node {

	char value[100];
	struct queue_node* link;

}QN;


typedef struct queue {

	int size;
	QN* front;
	QN* rear;

}Queue;

void init_queue(Queue* q);

int is_queue_full(Queue* q);

int is_queue_empty(Queue* q);

void enqueue(Queue* q, char* value);

char* dequeue(Queue* q);

void print_queue(Queue* q);